import React, { useState } from 'react';
import bannerImage from './assets/images/bdg_win_banner_1779878237426.png';

const REDIRECT_URL = "https://bdgwinin.com//#/register?invitationCode=364632010008";

export default function App() {
  const [isRedirecting, setIsRedirecting] = useState(false);

  const handleRegister = (e?: React.MouseEvent) => {
    if (e) e.preventDefault();
    setIsRedirecting(true);
    
    // Quick visual cue, then redirect
    setTimeout(() => {
      window.location.replace(REDIRECT_URL);
    }, 500);
  };

  return (
    <div className="min-h-screen bg-white text-gray-900 font-sans">
      {/* Top Bar */}
      <div className="w-full bg-[#404040] h-12 flex justify-center items-stretch gap-0.5 md:gap-1 p-0">
        <a href="#" onClick={handleRegister} className="w-32 md:w-48 bg-[#e8cd82] flex items-center justify-center text-white text-sm hover:bg-[#d9c471] transition-colors">
          Login
        </a>
        <a href="#" onClick={handleRegister} className="w-32 md:w-48 bg-[#e8cd82] flex items-center justify-center text-white text-sm hover:bg-[#d9c471] transition-colors">
          Register
        </a>
      </div>

      <div className="max-w-[1200px] mx-auto px-4 md:px-8">
        {/* Header */}
        <header className="flex justify-between items-center py-6 border-b border-gray-100">
          <div className="flex items-center gap-3 cursor-pointer" onClick={handleRegister}>
            <div className="bg-[#ffb020] text-black font-bold px-1.5 py-0.5 text-xs tracking-tight rounded-sm">
              BDG
            </div>
            <h1 className="text-2xl md:text-3xl font-normal text-gray-800">BDG Win Login</h1>
          </div>
          <nav className="flex gap-4 md:gap-6">
            <a href="#" onClick={handleRegister} className="text-[#00b0f0] hover:underline text-sm md:text-base">Home</a>
            <a href="#" onClick={handleRegister} className="text-[#00b0f0] hover:underline text-sm md:text-base">Blog</a>
          </nav>
        </header>

        {/* Main Content */}
        <main className="py-10 max-w-[800px] mx-auto overflow-x-hidden">
          <h2 className="text-2xl text-gray-800 font-normal mb-8 text-left">BDG Win Login</h2>
          
          {/* Banner Box */}
          <div className="w-full relative cursor-pointer mb-6" onClick={handleRegister}>
            <img src={bannerImage} alt="BDG WIN Colour Prediction App" className="w-full h-auto object-cover rounded shadow-lg" />
          </div>

          <div className="flex justify-center mb-8">
            <button onClick={handleRegister} className="bg-[#00b0f0] hover:bg-[#0090d0] text-white px-6 md:px-8 py-2.5 rounded-full text-base font-normal transition-colors">
              {isRedirecting ? 'Redirecting...' : 'Register On BDG Win'}
            </button>
          </div>

          <div className="w-full overflow-x-auto mb-8">
            <table className="w-full border-collapse border border-gray-300 text-sm">
              <tbody>
                <tr className="border-b border-gray-300">
                  <td className="p-3 border-r border-gray-300 w-1/2 text-gray-600 bg-white">App Name</td>
                  <td className="p-3 font-bold text-gray-800 w-1/2 bg-white">BDG Win</td>
                </tr>
                <tr className="border-b border-gray-300">
                  <td className="p-3 border-r border-gray-300 w-1/2 text-gray-600 bg-white">Invite Code</td>
                  <td className="p-3 font-bold text-gray-800 w-1/2 bg-white">277755099619</td>
                </tr>
                <tr>
                  <td className="p-3 border-r border-gray-300 w-1/2 text-gray-600 bg-white">Promotion Bonus</td>
                  <td className="p-3 font-bold text-gray-800 w-1/2 bg-white">Up To ₹3650</td>
                </tr>
              </tbody>
            </table>
          </div>

          <div className="text-gray-600 text-sm leading-relaxed text-left flex flex-col gap-4">
            <p>
              Register on the BDG Win and know what it's like to make money on it. As you register, you will experience how users make money from the BDG Win and how you will make money by playing games on it. Every game you play on this app will make you money, but first, you need to win that game, and you can multiply your money. You
            </p>
          </div>

        </main>
      </div>
    </div>
  );
}
